# myblog_BI
A simple blog website where you can view all you blogs, create, edit or delete them. 
